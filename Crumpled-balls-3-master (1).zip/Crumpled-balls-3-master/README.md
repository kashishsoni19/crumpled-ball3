Crumpled balls-3

